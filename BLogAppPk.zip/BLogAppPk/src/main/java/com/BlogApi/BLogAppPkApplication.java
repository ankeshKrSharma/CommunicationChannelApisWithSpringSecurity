package com.BlogApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BLogAppPkApplication {

	public static void main(String[] args) {
		SpringApplication.run(BLogAppPkApplication.class, args);
	}

}
