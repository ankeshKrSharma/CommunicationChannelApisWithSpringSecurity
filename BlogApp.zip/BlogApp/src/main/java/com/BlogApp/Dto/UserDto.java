package com.BlogApp.Dto;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserDto {
	
	  private int userid; 
	  @NotNull
	  @Size(min = 3, max = 15, message = "name should be in between 3 and 15")
	  private String name;
	  @Email(message = "Email Address not Valid!!")
	  private String email;
	  @Pattern(regexp = "[A-Za-z0-9]+")
	  private String password;
	  @NotBlank(message = "about should not be blank")
	  private String about;
	
	  
	  

}
