package com.BlogApp.security;

import java.io.IOException;


import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.MalformedJwtException;
@Component
public class JwtAuthenticationFeilter extends OncePerRequestFilter{
	
	@Autowired
	private UserDetailsService userDetailService;
	
	@Autowired
	private JwtTokenHelper jwtTokenHelper;

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		  //get token
		String requestToken =request.getHeader("Autorization");
		
		String userName =null;
		String token =null;
		
		if (requestToken!=null && requestToken.startsWith("Bearer")) {
			 token =requestToken.substring(7);
			 try {
				 userName=jwtTokenHelper.extractUsername(token);
			} catch (IllegalArgumentException e) {
				System.out.println("Not get the token!!");
			}
			 catch (ExpiredJwtException e) {
					System.out.println("the token!! get exp");
				}
			 catch (MalformedJwtException e) {
					System.out.println("the token is not valid!!");
				}
			
		}
		else {
			System.out.println("JWT token not starts with Bearer");
		}
		
		//after getting token jwt validates that token
		if (userName!=null && SecurityContextHolder.getContext().getAuthentication()==null) {
			UserDetails userDetails = userDetailService.loadUserByUsername(userName);
			if (jwtTokenHelper.validateToken(token, userDetails)) {
				//all are good we need to authenticate now
				UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(
						userDetails,null, userDetails.getAuthorities());
				usernamePasswordAuthenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
				SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
			}
			else {
				System.out.println("Invalid username");
			}
		}
		else {
			System.out.println("username password invalid!!");
		}
		
		 filterChain.doFilter(request, response);
	}

}
