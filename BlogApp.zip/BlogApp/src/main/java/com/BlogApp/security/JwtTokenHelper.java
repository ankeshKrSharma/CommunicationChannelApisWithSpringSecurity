package com.BlogApp.security;

import java.util.*;
import java.util.function.Function;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Component
public class JwtTokenHelper {
	
	public static final long JWT_TOkEN_VALIDITY=5*10*60;
	
	private String secret ="JwtTokenKey";
	
	   // Extract the username from a token
	 public String extractUsername(String token) {
	        return extractClaim(token, Claims::getSubject);
	    }
    
    // Extract the expiration date from a token
    private Date extractExpiration(String token) {
        return extractClaim(token, Claims::getExpiration);
    }

    // Extract an arbitrary claim from a token
    public <T> T extractClaim(String token, Function<Claims, T> claimsResolver) {
        final Claims claims = extractAllClaims(token);
        return claimsResolver.apply(claims);
    }
    
    // Extract all claims from a token
    private Claims extractAllClaims(String token) {
        return Jwts.parser()
                .setSigningKey(secret)
                .parseClaimsJws(token)
                .getBody();
    }
    
    public Boolean isTokenExpired(String token) {
        final Date expiration = extractExpiration(token);
        return expiration.before(new Date());
    }
    
    // Generate a JWT token from user details
    public String generateToken(UserDetails userDetails) {
        Map<String, Object> claims = new HashMap<>();
        return createToken(claims, userDetails.getUsername());
    }
    
 // Create a token
    private String createToken(Map<String, Object> claims, String subject) {

        return Jwts.builder()
                .setClaims(claims)
                .setSubject(subject)
                .setIssuedAt(new Date(System.currentTimeMillis()+JWT_TOkEN_VALIDITY*100))
                .signWith(SignatureAlgorithm.HS512,secret)
                .compact();
    }
    
    // Check if a token is expired also validate token
    public Boolean validateToken(String token,UserDetails userDetails) {
        final String username=extractUsername(token);
        return username.equals(userDetails.getUsername())&&isTokenExpired(token);
    }
    
    
}
