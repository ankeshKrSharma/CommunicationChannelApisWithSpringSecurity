package com.BlogApp.Exception;



public class ResourceNotFoundForUserSecurity extends RuntimeException{
	
	 private String ResourceName;
	 private String fieldName;
	 private String fieldValue;
	public ResourceNotFoundForUserSecurity(String resourceName, String fieldName, String fieldValue) {
		super(String.format("%s not found with %s:'%s'", resourceName,fieldName,fieldValue));
		ResourceName = resourceName;
		this.fieldName = fieldName;
		this.fieldValue = fieldValue;
	}
	public String getResourceName() {
		return ResourceName;
	}
	public void setResourceName(String resourceName) {
		ResourceName = resourceName;
	}
	public String getFieldName() {
		return fieldName;
	}
	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}
	public String getFieldValue() {
		return fieldValue;
	}
	public void setFieldValue(String fieldValue) {
		this.fieldValue = fieldValue;
	}
	
	
	 
	 

}
