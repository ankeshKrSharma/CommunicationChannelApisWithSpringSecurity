package com.BlogApp.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.BlogApp.Dto.CategoryDto;
import com.BlogApp.service.CategoryService;

@RestController
@RequestMapping("/api/categories")
public class CategoryController {
	
	@Autowired
	private CategoryService categoryService;
	
	@PostMapping("/")
	public ResponseEntity<CategoryDto> createOneCategory(@Valid @RequestBody CategoryDto categoryDto){
		  CategoryDto createCategory = categoryService.createCategory(categoryDto);
		return new ResponseEntity<>(createCategory,HttpStatus.CREATED);
		
	}
	
	@PutMapping("/{categoryId}")
	public ResponseEntity<CategoryDto> updateOneCategory(@RequestBody CategoryDto categoryDto,@PathVariable(name="categoryId") int categoryId){
		CategoryDto updateCategory = categoryService.updateCategory(categoryDto, categoryId);
		return new ResponseEntity<>(updateCategory,HttpStatus.OK);
		
	}
	
	@DeleteMapping("/{categoryId}")
	public ResponseEntity<String> deleteOneCategoryRecord(@RequestBody CategoryDto categoryDto,@PathVariable(name="categoryId") int categoryId){
		categoryService.deleteCategory(categoryId);
		return new ResponseEntity<String>("Category Record Deleted!!",HttpStatus.OK);
		
	}
	
	@GetMapping("/{categoryId}")
	public ResponseEntity<CategoryDto> getOneCategory(@PathVariable(name="categoryId") int categoryId){
		   CategoryDto oneCategoryById = categoryService.getOneCategoryById(categoryId);
		return new ResponseEntity<>(oneCategoryById,HttpStatus.OK);
	}
	
	@GetMapping("/")
	public List<CategoryDto> getAllCategory(){
		List<CategoryDto> allCategory = categoryService.getAllCategory();
		return allCategory;
		
	}

}
