package com.BlogApp.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.BlogApp.Dto.UserDto;
import com.BlogApp.service.UserService;

@RestController
@RequestMapping("/api/user")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@PostMapping("/")
	public ResponseEntity<UserDto> createOneUser(@Valid @RequestBody UserDto userDto){
		  UserDto createUser = userService.createUser(userDto);
		return new ResponseEntity<>(createUser,HttpStatus.CREATED);
		
	}
	
	@PutMapping("/{userId}")
	public ResponseEntity<UserDto> updateOneUser(@PathVariable(name="userId") int userId,@RequestBody UserDto userDto){
		UserDto updateUser = userService.updateUser(userDto, userId);
		return new ResponseEntity<>(updateUser,HttpStatus.OK);
		
	}
	
	@GetMapping("/")
	public List<UserDto> getAlluser(){
		List<UserDto> allUser = userService.getAllUser();
		return allUser;
		
	}
	
	@GetMapping("/{userId}")
	public ResponseEntity<UserDto> getOneUser(@PathVariable(name="userId") int userId){
		UserDto userById = userService.getUserById(userId);
		return new ResponseEntity<>(userById,HttpStatus.ACCEPTED);
		
	}
	
	
	@DeleteMapping("/{userId}")
	public ResponseEntity<String> deleteOneUser(@PathVariable(name="userId") int userId){
		userService.deleteUser(userId);
		return new ResponseEntity<String>("User Deleted!",HttpStatus.OK);
		
	}
	
	
	

}
