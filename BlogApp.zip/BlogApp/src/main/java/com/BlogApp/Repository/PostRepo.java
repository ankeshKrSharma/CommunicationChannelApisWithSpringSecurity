package com.BlogApp.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.BlogApp.entites.Category;
import com.BlogApp.entites.Post;
import com.BlogApp.entites.User;

public interface PostRepo extends JpaRepository<Post, Integer> {
	
	List<Post> findByUser(User user);
	List<Post> findByCategory(Category category);
	List<Post> findByTitileContaining(String titile);


}
