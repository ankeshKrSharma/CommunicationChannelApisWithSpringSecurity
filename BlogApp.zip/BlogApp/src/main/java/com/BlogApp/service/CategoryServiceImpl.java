package com.BlogApp.service;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.BlogApp.Dto.CategoryDto;
import com.BlogApp.Exception.ResouceNotFoundException;
import com.BlogApp.Repository.CategoryRepo;
import com.BlogApp.entites.Category;

@Service
public class CategoryServiceImpl implements CategoryService {
	
	@Autowired
	private CategoryRepo categoryRepo;
	
	@Autowired
	private ModelMapper modelMapper;

	@Override
	public CategoryDto createCategory(CategoryDto categoryDto) {
		Category category = modelMapper.map(categoryDto, Category.class);
		Category save = categoryRepo.save(category);	  
		return modelMapper.map(save, CategoryDto.class);
	}

	@Override
	public CategoryDto updateCategory(CategoryDto categoryDto, int categoryId) {
		 Category category = categoryRepo.findById(categoryId).orElseThrow(
				  ()-> new ResouceNotFoundException("Category", "categoryId", categoryId)
				 );
		 category.setCategoryTitle(categoryDto.getCategoryTitle());
		 category.setDescription(categoryDto.getDescription());		 
		return modelMapper.map(category, CategoryDto.class);
	}

	@Override
	public void deleteCategory(int categoryId) {
		 Category category = categoryRepo.findById(categoryId).orElseThrow(
				  ()-> new ResouceNotFoundException("Category", "categoryId", categoryId)
				 );
		 categoryRepo.delete(category);

	}

	@Override
	public CategoryDto getOneCategoryById(int categoryId) {
		 Category category = categoryRepo.findById(categoryId).orElseThrow(
				  ()-> new ResouceNotFoundException("Category", "categoryId", categoryId)
				 );
		return modelMapper.map(category, CategoryDto.class);
	}

	@Override
	public List<CategoryDto> getAllCategory() {
		List<Category> category = categoryRepo.findAll();
		List<CategoryDto> collect = category.stream().map(cat-> modelMapper.map(cat, CategoryDto.class)).collect(Collectors.toList());
		return collect;
	}

}
