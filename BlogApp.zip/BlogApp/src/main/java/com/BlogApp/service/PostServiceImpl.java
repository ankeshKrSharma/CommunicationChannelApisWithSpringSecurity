package com.BlogApp.service;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.BlogApp.Dto.PostDto;
import com.BlogApp.Exception.ResouceNotFoundException;
import com.BlogApp.Repository.CategoryRepo;
import com.BlogApp.Repository.PostRepo;
import com.BlogApp.Repository.UserRepo;
import com.BlogApp.entites.Category;
import com.BlogApp.entites.Post;
import com.BlogApp.entites.User;
import com.BlogApp.payload.PostResponse;

import lombok.Value;

@Service
public class PostServiceImpl implements PostService {
	
	@Autowired
	private PostRepo postRepo;
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	private UserRepo userRepo;
	
	@Autowired
	private CategoryRepo categoryRepo;

	
	
	@Override
	public PostDto createPost(PostDto postDto,int userId,int categoryId) {
		User user = userRepo.findById(userId).orElseThrow(
				 ()-> new ResouceNotFoundException("User", "userId", userId)
				);
		Category category = categoryRepo.findById(categoryId).orElseThrow(
				()-> new ResouceNotFoundException("Category", "categoryId", categoryId)
				);
		
		 Post post = modelMapper.map(postDto, Post.class);
		 post.setImageName("default.png");
		 post.setDate(new Date());
		 post.setUser(user);
		 post.setCategory(category);
		 Post save = postRepo.save(post);
		 
		return modelMapper.map(save, PostDto.class);
	}

	@Override
	public PostDto updatePost(PostDto postDto, int postId) {
		Post post = postRepo.findById(postId).orElseThrow(
				  ()-> new ResouceNotFoundException("Post", "postId", postId)
				);
		post.setTitile(postDto.getTitile());
		post.setContent(postDto.getContent());
		post.setImageName(postDto.getImageName());
		PostDto dto = modelMapper.map(post, PostDto.class);
		return dto;
	}

	@Override
	public void deletePost(int postId) {
		Post post = postRepo.findById(postId).orElseThrow(
				  ()-> new ResouceNotFoundException("Post", "postId", postId)
				);
	
		postRepo.delete(post);
	}

	@Override
	public PostResponse getAllPosts(int pageNumber, int pageSize,String sortBy) {
		/*
		 * int pageSize=5; int pageNumber=1;
		 */
	  Pageable p = PageRequest.of(pageNumber, pageSize, Sort.by(sortBy).descending());
		
	 Page<Post> pagePost = postRepo.findAll(p);
	 List<Post> posts = pagePost.getContent();
		 
	  List<PostDto> dto = posts.stream().map(post->modelMapper.map(post, PostDto.class)).collect(Collectors.toList());
	  
	  PostResponse postRepsponse = new PostResponse();
	  postRepsponse.setContent(dto);
	  postRepsponse.setPageNumber(pagePost.getNumber());
	  postRepsponse.setPageSize(pagePost.getSize());
	  postRepsponse.setTotalElements(pagePost.getTotalElements());
	  postRepsponse.setTotalPages(pagePost.getTotalPages());
	  postRepsponse.setLastPage(pagePost.isLast());
		return postRepsponse;
	}

	@Override
	public PostDto getOnePostById(int postId) {
		Post post = postRepo.findById(postId).orElseThrow(
				  ()-> new ResouceNotFoundException("Post", "postId", postId)
				);
		PostDto dto = modelMapper.map(post, PostDto.class);
		return dto;
	}

	@Override
	public List<PostDto> getAllPostByCategory(int categoryId) {
		Category category = categoryRepo.findById(categoryId).orElseThrow(
				 ()-> new ResouceNotFoundException("category", "categoryId", categoryId)
				);
		List<Post> posts = postRepo.findByCategory(category);
		List<PostDto> dto = posts.stream().map(post->modelMapper.map(post, PostDto.class)).collect(Collectors.toList());
		return dto;
	}

	@Override
	public List<PostDto> getAllPostByUser(int userId) {
		User user = userRepo.findById(userId).orElseThrow(
				 ()-> new ResouceNotFoundException("user", "userId", userId)
				);
		List<Post> posts = postRepo.findByUser(user);
		List<PostDto> collect = posts.stream().map(post->modelMapper.map(post, PostDto.class)).collect(Collectors.toList());
		return collect;
	}

	@Override
	public List<PostDto> searchPost(String keyword) {
		List<Post> findByTitileContaining = postRepo.findByTitileContaining(keyword);
		List<PostDto> collect = findByTitileContaining.stream().map(post->modelMapper.map(post, PostDto.class)).collect(Collectors.toList());
		return collect;
	}
	


}
