package com.BlogApp.service;

import java.util.List;

import com.BlogApp.Dto.PostDto;
import com.BlogApp.entites.Post;
import com.BlogApp.payload.PostResponse;

public interface PostService {
	
	PostDto createPost(PostDto postDto,int userId,int categoryId);
	PostDto updatePost(PostDto postDto,int postId);
	void deletePost(int postId);
	PostResponse getAllPosts(int pageNumber, int pageSize,String sortBy);
	PostDto getOnePostById(int postId);
	List<PostDto> getAllPostByCategory(int categoryId);
	List<PostDto> getAllPostByUser(int userId);
	List<PostDto> searchPost(String keyword);
	

}
