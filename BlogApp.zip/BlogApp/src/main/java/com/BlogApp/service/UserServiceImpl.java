package com.BlogApp.service;

import java.util.List;

import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.BlogApp.Dto.UserDto;
import com.BlogApp.Exception.ResouceNotFoundException;
import com.BlogApp.Repository.UserRepo;
import com.BlogApp.entites.User;

@Service
public class UserServiceImpl implements UserService{
	
	@Autowired
	private UserRepo userRepo;
	
	@Autowired
	private ModelMapper modelMapper;	

	@Override
	public UserDto createUser(UserDto userdto) {
	   User user = modelMapper.map(userdto, User.class);
	   User savedUser = userRepo.save(user);
	   UserDto dto = modelMapper.map(savedUser, UserDto.class);	   
		return dto;
	}

	@Override
	public UserDto updateUser(UserDto userdto, int userId) {
	    User user = userRepo.findById(userId).orElseThrow(
	    		  ()-> new ResouceNotFoundException("User", "id", userId)
	    		);
	    user.setName(userdto.getName());
	    user.setEmail(userdto.getEmail());
	    user.setPassword(userdto.getPassword());
	    user.setAbout(userdto.getAbout());
	   //jpa automatically save no need to call save method again  
	    UserDto dto = modelMapper.map(user, UserDto.class);
		return dto;
	}

	@Override
	public UserDto getUserById(int userId) {
		User user = userRepo.findById(userId).orElseThrow(
	    		  ()-> new ResouceNotFoundException("User", "id", userId)
	    		);
		UserDto dto = modelMapper.map(user, UserDto.class);
		return dto;
	}

	@Override
	public List<UserDto> getAllUser() {
		List<User> users = userRepo.findAll();
		
		 List<UserDto> dtoList = users.stream().map( user-> modelMapper.map(user, UserDto.class)).collect(Collectors.toList());
		return dtoList;
	}

	@Override
	public void deleteUser(int userId) {
		User user = userRepo.findById(userId).orElseThrow(
	    		  ()-> new ResouceNotFoundException("User", "id", userId)
	    		);
		userRepo.delete(user);
		
	}
	

}
