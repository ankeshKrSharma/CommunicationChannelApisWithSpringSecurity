package com.BlogApp.service;

import java.util.List;

import com.BlogApp.Dto.UserDto;

public interface UserService {
	
	UserDto createUser(UserDto userdto);
	UserDto updateUser(UserDto userdto,int userId);
	UserDto getUserById(int userId);
	List<UserDto> getAllUser();
	void deleteUser(int userId);
}
