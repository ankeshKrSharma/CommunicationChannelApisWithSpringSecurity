package com.BlogApp.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.BlogApp.Dto.CommentDto;
import com.BlogApp.Exception.ResouceNotFoundException;
import com.BlogApp.Repository.CommentRepo;
import com.BlogApp.Repository.PostRepo;
import com.BlogApp.entites.Comment;
import com.BlogApp.entites.Post;
@Service
public class CommentServiceImpl implements CommentService {
	
	@Autowired
	private PostRepo postRepo;
	
	@Autowired
	private CommentRepo commentRepo;
	
	@Autowired
	private ModelMapper modelMapper;
	

	@Override
	public CommentDto createComment(CommentDto commentDto, int postId) {
		Post post = postRepo.findById(postId).orElseThrow(
				 ()-> new ResouceNotFoundException("post", "postId", postId)
				);
		Comment comment = modelMapper.map(commentDto, Comment.class);
		comment.setPost(post);
		Comment save = commentRepo.save(comment);	
		return modelMapper.map(save, CommentDto.class);
	}

	@Override
	public void deleteComment(int commentId) {
		Comment comment = commentRepo.findById(commentId).orElseThrow(
				()-> new ResouceNotFoundException("comment", "commentId", commentId)
				);
          commentRepo.delete(comment);
	}

}
