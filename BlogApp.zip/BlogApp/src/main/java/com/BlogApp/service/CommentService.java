package com.BlogApp.service;

import com.BlogApp.Dto.CommentDto;

public interface CommentService {
	
 CommentDto	createComment(CommentDto commentDto,int postId);
 void deleteComment(int commentId);

}
